import platform
platform.platform()
platform.python_version()

import numpy as np
import numpy.linalg as LA
import math

import sympy
from sympy import var

H=sympy.Point3D(-20.76,74.26,-73.7)
tockanax=-(-29.21/-80.24)
ravnina=sympy.Plane(sympy.Point3D(tockanax,0,0),(-80.24,-78.22,6.53))
presjeknaravnini=ravnina.projection(H)
Hc=presjeknaravnini+H.direction_ratio(presjeknaravnini)
E=sympy.Point3D(20.48,46.73,26.44)
print(round(Hc.distance(E),5))


